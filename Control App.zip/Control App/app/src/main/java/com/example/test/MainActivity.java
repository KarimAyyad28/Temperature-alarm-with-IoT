package com.example.emeccontrolapp;


import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private static final String URL_Data1 = "https://api.thingspeak.com/channels/1144608/fields/1.json?api_key=3EY0OEGXAX5C0QWE&results=2";
    private static final String URL_Data2 = "https://api.thingspeak.com/channels/1144608/fields/2.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch1URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field1=1";
    private static final String write_Switch1off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field1=0";
    private static final String read_Switch1Status = "https://api.thingspeak.com/channels/1144608/fields/3.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch2URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field2=1";
    private static final String write_Switch2off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field2=0";
    private static final String read_Switch2Status = "https://api.thingspeak.com/channels/1144608/fields/4.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch3URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field3=1";
    private static final String write_Switch3off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field3=0";
    private static final String read_Switch3Status = "https://api.thingspeak.com/channels/1144608/fields/5.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch4URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field4=1";
    private static final String write_Switch4off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field4=0";
    private static final String read_Switch4Status = "https://api.thingspeak.com/channels/1144608/fields/6.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch5URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field5=1";
    private static final String write_Switch5off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field5=0";
    private static final String read_Switch5Status = "https://api.thingspeak.com/channels/1144608/fields/7.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    private static final String write_Switch6URLon = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field6=1";
    private static final String write_Switch6off = "https://api.thingspeak.com/update?api_key=I9VIOY9A7ELZYTW1&field6=0";
    private static final String read_Switch6Status = "https://api.thingspeak.com/channels/1144608/fields/8.json?api_key=3EY0OEGXAX5C0QWE&results=2";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Handler handler1 = new Handler();
        final Handler handler2 = new Handler();
        final Handler handler3 = new Handler();
        final Handler handler4 = new Handler();
        final Handler handler5 = new Handler();
        final Handler handler6 = new Handler();
        final Handler handler7 = new Handler();



        final RadioButton onButton1 = findViewById(R.id.onBtn1);
        final RadioButton offButton1 = findViewById(R.id.offBtn1);
        final RadioButton onButton2 = findViewById(R.id.onBtn2);
        final RadioButton offButton2 = findViewById(R.id.offBtn2);
        final RadioButton onButton3 = findViewById(R.id.onBtn3);
        final RadioButton offButton3 = findViewById(R.id.offBtn3);
        final RadioButton onButton4 = findViewById(R.id.onBtn4);
        final RadioButton offButton4 = findViewById(R.id.offBtn4);
        final RadioButton onButton5 = findViewById(R.id.onBtn5);
        final RadioButton offButton5 = findViewById(R.id.offBtn5);
        final RadioButton onButton6 = findViewById(R.id.onBtn6);
        final RadioButton offButton6 = findViewById(R.id.offBtn6);


        final Runnable r1 = new Runnable() {
            public void run() {
                onButton1.setEnabled(true);
                offButton1.setEnabled(true);

                onButton1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView1();
                        sendData1on();
                        offButton1.setEnabled(false);
                        onButton1.setEnabled(false);
                        offButton1.setChecked(false);
                        onButton1.setChecked(false);

                    }
                });

                offButton1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView1();
                        sendData1off();
                        offButton1.setEnabled(false);
                        onButton1.setEnabled(false);
                        offButton1.setChecked(false);
                        onButton1.setChecked(false);

                    }
                });

                handler1.postDelayed(this, 20000); // 15000 = 15 sec
                //        onOffSwitch.setEnabled(true);

            }
        };
        handler1.post(r1);




        final Runnable r3 = new Runnable() {
            public void run() {
                onButton2.setEnabled(true);
                offButton2.setEnabled(true);

                onButton2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView2();
                        sendData2on();
                        offButton2.setEnabled(false);
                        onButton2.setEnabled(false);
                        offButton2.setChecked(false);
                        onButton2.setChecked(false);

                    }
                });

                offButton2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView2();
                        sendData2off();
                        offButton2.setEnabled(false);
                        onButton2.setEnabled(false);
                        offButton2.setChecked(false);
                        onButton2.setChecked(false);

                    }
                });



                handler3.postDelayed(this, 20000); // 15000 = 15 sec

            }
        };
        handler3.post(r3);



        final Runnable r4 = new Runnable() {
            public void run() {
                onButton3.setEnabled(true);
                offButton3.setEnabled(true);

                onButton3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView3();
                        sendData3on();
                        offButton3.setEnabled(false);
                        onButton3.setEnabled(false);
                        offButton3.setChecked(false);
                        onButton3.setChecked(false);

                    }
                });

                offButton3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView3();
                        sendData3off();
                        offButton3.setEnabled(false);
                        onButton3.setEnabled(false);
                        offButton3.setChecked(false);
                        onButton3.setChecked(false);

                    }
                });



                handler4.postDelayed(this, 20000); // 15000 = 15 sec

            }
        };
        handler4.post(r4);

        final Runnable r5 = new Runnable() {
            public void run() {
                onButton4.setEnabled(true);
                offButton4.setEnabled(true);

                onButton4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView4();
                        sendData4on();
                        offButton4.setEnabled(false);
                        onButton4.setEnabled(false);
                        offButton4.setChecked(false);
                        onButton4.setChecked(false);

                    }
                });

                offButton4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView4();
                        sendData4off();
                        offButton4.setEnabled(false);
                        onButton4.setEnabled(false);
                        offButton4.setChecked(false);
                        onButton4.setChecked(false);

                    }
                });



                handler5.postDelayed(this, 20000); // 15000 = 15 sec

            }
        };
        handler5.post(r5);

        final Runnable r6 = new Runnable() {
            public void run() {
                onButton5.setEnabled(true);
                offButton5.setEnabled(true);

                onButton5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView5();
                        sendData5on();
                        offButton5.setEnabled(false);
                        onButton5.setEnabled(false);
                        offButton5.setChecked(false);
                        onButton5.setChecked(false);

                    }
                });

                offButton5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView5();
                        sendData5off();
                        offButton5.setEnabled(false);
                        onButton5.setEnabled(false);
                        offButton5.setChecked(false);
                        onButton5.setChecked(false);

                    }
                });



                handler6.postDelayed(this, 20000); // 15000 = 15 sec

            }
        };
        handler6.post(r6);

        final Runnable r7 = new Runnable() {
            public void run() {
                onButton6.setEnabled(true);
                offButton6.setEnabled(true);

                onButton6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView6();
                        sendData6on();
                        offButton6.setEnabled(false);
                        onButton6.setEnabled(false);
                        offButton6.setChecked(false);
                        onButton6.setChecked(false);

                    }
                });

                offButton6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        statusView6();
                        sendData6off();
                        offButton6.setEnabled(false);
                        onButton6.setEnabled(false);
                        offButton6.setChecked(false);
                        onButton6.setChecked(false);

                    }
                });



                handler7.postDelayed(this, 20000); // 15000 = 15 sec

            }
        };
        handler7.post(r7);




        final Runnable r2 = new Runnable() {
            public void run() {
                getTempData();
                getHumData();
                statusView1();
                statusView2();
                statusView3();
                statusView4();
                statusView5();
                statusView6();
                handler2.postDelayed(this, 2000); // 15000 = 15 sec

            }
        };
        handler2.post(r2);



    }

    private void getTempData() {
        final TextView tempUpdate = findViewById(R.id.temperatureUpdate);


        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_Data1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            tempUpdate.setText(o.getString("field1"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void getHumData() {
        final TextView humUpdate = findViewById(R.id.humidityUpdate);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_Data2,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);

                            humUpdate.setText(o.getString("field2"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData1on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch1URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData2on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch2URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData3on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch3URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData4on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch4URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData5on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch5URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData6on() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch6URLon,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData1off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch1off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData2off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch2off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData3off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch3off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData4off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch4off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData5off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch5off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    private void sendData6off() {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, write_Switch6off,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        requestQueue.add(stringRequest);
        requestQueue.start();


    }

    public void statusView1() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton1 = findViewById(R.id.onBtn1);
        final RadioButton offButton1 = findViewById(R.id.offBtn1);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch1Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field3");
                            if (value.equals("1"))
                            {onButton1.setChecked(true);
                                offButton1.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton1.setChecked(false);
                                offButton1.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

    public void statusView2() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton2 = findViewById(R.id.onBtn2);
        final RadioButton offButton2 = findViewById(R.id.offBtn2);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch2Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field4");
                            if (value.equals("1"))
                            {onButton2.setChecked(true);
                                offButton2.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton2.setChecked(false);
                                offButton2.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

    public void statusView3() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton3 = findViewById(R.id.onBtn3);
        final RadioButton offButton3 = findViewById(R.id.offBtn3);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch3Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field5");
                            if (value.equals("1"))
                            {onButton3.setChecked(true);
                                offButton3.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton3.setChecked(false);
                                offButton3.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

    public void statusView4() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton4 = findViewById(R.id.onBtn4);
        final RadioButton offButton4 = findViewById(R.id.offBtn4);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch4Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field6");
                            if (value.equals("1"))
                            {onButton4.setChecked(true);
                                offButton4.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton4.setChecked(false);
                                offButton4.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

    public void statusView5() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton5 = findViewById(R.id.onBtn5);
        final RadioButton offButton5 = findViewById(R.id.offBtn5);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch5Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field7");
                            if (value.equals("1"))
                            {onButton5.setChecked(true);
                                offButton5.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton5.setChecked(false);
                                offButton5.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

    public void statusView6() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final RadioButton onButton6 = findViewById(R.id.onBtn6);
        final RadioButton offButton6 = findViewById(R.id.offBtn6);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, read_Switch6Status,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            JSONArray array = jsonObject.getJSONArray("feeds");
                            JSONObject o = array.getJSONObject(1);
                            String value = o.getString("field8");
                            if (value.equals("1"))
                            {onButton6.setChecked(true);
                                offButton6.setChecked(false);
                            }
                            else if (value.equals("0"))
                            {onButton6.setChecked(false);
                                offButton6.setChecked(true);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });


        requestQueue.add(stringRequest);
        requestQueue.start();
    }

}